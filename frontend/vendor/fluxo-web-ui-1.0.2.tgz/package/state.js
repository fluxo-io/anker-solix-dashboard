const LEVELS = new Set(['success', 'info', 'warning', 'error']);
export function levelOf(value) {
  const level = String(value || 'info').split(':')[0];
  return level === 'danger' ? 'error' : LEVELS.has(level) ? level : 'info';
}

/** Clock-independent state; the view alone decides whether time is visible. */
export class NotificationState {
  constructor() { this.items = []; this.events = new Map(); this.sequence = 0; }
  add(input) {
    const message = String(input?.message ?? '').trim();
    if (!message) return null;
    const eventId = input.eventId == null ? null : String(input.eventId);
    if (eventId && this.events.has(eventId)) return null;
    const level = levelOf(input.level);
    const item = {
      id: ++this.sequence, message, level, eventId,
      remaining: (level === 'success' || level === 'info') && !input.persistent ? 7000 : Infinity,
    };
    this.items.push(item);
    if (eventId) {
      this.events.set(eventId, item.id);
      // Bounded page-lifetime replay memory; no browser storage or message history.
      if (this.events.size > 1024) this.events.delete(this.events.keys().next().value);
    }
    return item;
  }
  visible() {
    const priority = {error: 3, warning: 2, success: 1, info: 1};
    return [...this.items].sort((a, b) => priority[b.level] - priority[a.level] || b.id - a.id)
      .slice(0, 3).sort((a, b) => a.id - b.id);
  }
  remove(id) { this.items = this.items.filter(item => item.id !== id); }
  elapse(id, milliseconds) {
    const item = this.items.find(value => value.id === id);
    if (!item || !Number.isFinite(item.remaining)) return false;
    item.remaining = Math.max(0, item.remaining - Math.max(0, milliseconds));
    if (item.remaining === 0) { this.remove(id); return true; }
    return false;
  }
}
