# @fluxo/web-ui

Gemeinsamer Meldungsadapter für Flask/Jinja, JavaScript-Anfragen und Dash.
Keine Laufzeitabhängigkeit von der zentralen Bibliothek; als festes npm-Archiv
unter `frontend/vendor/` übernehmen. Keine fremden Framework-Abhängigkeiten.

```js
import {initNotifications, notify} from '@fluxo/web-ui';
import '@fluxo/web-ui/styles.css';
initNotifications();
notify({level: 'success', message: 'Gespeichert.', eventId: 'save:operation-id'});
```

Serverseitige Meldungen sicher als Text rendern:

```html
<div data-fluxo-notice data-level="success">Gespeichert.</div>
```

Ohne JavaScript bleiben diese Elemente sichtbar. Nach erfolgreicher Initialisierung
werden sie in Toasts überführt; ein MutationObserver unterstützt dynamische Dash-
Ausgaben mit stabilen `data-event-id`-Werten. Feldfehler und dauerhafte Zustände
tragen dieses Attribut nicht. Ereignis-IDs gehören zur konkreten Operation; zwei
getrennte Speichervorgänge dürfen nicht denselben Schlüssel bekommen.

`success` und `info` schließen nach sieben Sekunden sichtbarer Zeit; `warning`,
`error` und `{persistent: true}` bleiben. Hover, Fokus, ausgeblendeter Tab und die
geöffnete Liste weiterer Meldungen pausieren die verbleibende Zeit. Höchstens drei
Karten sind sichtbar; weitere bleiben in einer bedienbaren Liste, neue Fehler
werden priorisiert. Meldungen werden nicht in Browserstorage gespeichert.

Keine HTML-Nachrichten. Live-Regionen stehen vor dem Einfügen bereit. Toasts
übernehmen den offenen Dialogkontext, stehlen beim Erscheinen keinen Fokus und
geben ihn nach Schließen erreichbar zurück. Keine Nachrichten mit Tokens,
Patiententexten oder internen Fehlermeldungen. Aktionen in Toasts werden bewusst
nicht angeboten; nötige Handlungen bleiben im zugänglichen Seiteninhalt.

Die Darstellung verwendet vorhandene `--lumi-*` beziehungsweise `--fluxo-*`
Themevariablen. Position an die Navigation bei Bedarf mit `--notification-top`
anpassen. Angewandte Markenfarben werden nicht in dieses Paket kopiert.

Prüfen: `npm run check && npm test`. Verhalten zusätzlich in einer echten
Browserintegration einschließlich Dialog, Tastatur, 320/375 px und JS-Ausfall
prüfen; Node-Tests allein beweisen keine Screenreader-Ausgabe.
