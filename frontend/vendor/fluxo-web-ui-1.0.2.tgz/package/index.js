import {NotificationState} from './state.js';

let shared;

class Notifications {
  constructor(doc) {
    this.doc = doc;
    this.win = doc.defaultView;
    this.state = new NotificationState();
    this.cards = new Map();
    this.sources = new WeakSet();
    this.paused = new Set();
    this.announcements = {info: [], error: []};
    this.host = doc.createElement('section');
    this.host.className = 'fluxo-notifications';
    this.host.setAttribute('aria-label', 'Meldungen');
    this.stack = doc.createElement('div');
    this.stack.className = 'fluxo-notifications__stack';
    this.more = doc.createElement('details');
    this.more.className = 'fluxo-notifications__more';
    this.summary = doc.createElement('summary');
    this.archive = doc.createElement('div');
    this.more.append(this.summary, this.archive);
    this.regions = {};
    for (const [kind, role, live] of [['info', 'status', 'polite'], ['error', 'alert', 'assertive']]) {
      const region = doc.createElement('div');
      region.className = 'fluxo-notifications__live';
      region.setAttribute('role', role);
      region.setAttribute('aria-live', live);
      region.setAttribute('aria-atomic', 'true');
      this.regions[kind] = region;
    }
    this.host.append(this.stack, this.more, ...Object.values(this.regions));
    this.moveToContext();
    this.onVisibility = () => this.syncPause('hidden', doc.hidden);
    this.onFocus = () => this.syncPause('focus', this.host.contains(doc.activeElement));
    this.host.addEventListener('pointerenter', () => this.syncPause('hover', true));
    this.host.addEventListener('pointerleave', () => this.syncPause('hover', false));
    this.host.addEventListener('focusin', this.onFocus);
    this.host.addEventListener('focusout', () => this.win.queueMicrotask(this.onFocus));
    this.more.addEventListener('toggle', () => { this.syncPause('list', this.more.open); });
    doc.addEventListener('visibilitychange', this.onVisibility);
    this.onVisibility();
    this.observer = new this.win.MutationObserver(records => {
      if (records.some(record => !this.host.contains(record.target))) {
        this.moveToContext();
        this.scan();
      }
    });
    this.observer.observe(doc.documentElement, {childList: true, subtree: true, attributes: true, attributeFilter: ['open', 'class', 'aria-hidden']});
    this.render();
  }

  moveToContext() {
    const dialogs = [...this.doc.querySelectorAll('dialog[open], .modal.show, [role="dialog"][aria-modal="true"]')]
      .filter(node => node.getAttribute('aria-hidden') !== 'true' && !node.hidden && node.getClientRects().length);
    const target = dialogs.at(-1) || this.doc.body;
    if (this.host.parentElement !== target) target.append(this.host);
    this.host.toggleAttribute('data-dialog-context', target !== this.doc.body);
  }

  syncPause(reason, active) {
    if (active) this.paused.add(reason); else this.paused.delete(reason);
    this.syncTimers();
  }

  stopTimer(card) {
    if (card.timer != null) {
      this.win.clearTimeout(card.timer);
      card.timer = null;
      return this.state.elapse(card.item.id, this.win.performance.now() - card.started);
    }
    return false;
  }

  syncTimers() {
    const visible = new Set(this.state.visible().map(item => item.id));
    for (const card of this.cards.values()) {
      if (this.paused.size || !visible.has(card.item.id)) {
        if (this.stopTimer(card)) this.win.queueMicrotask(() => this.render());
      } else if (card.timer == null && Number.isFinite(card.item.remaining)) {
        card.started = this.win.performance.now();
        card.timer = this.win.setTimeout(() => {
          card.timer = null;
          this.state.remove(card.item.id);
          this.render();
        }, card.item.remaining);
      }
    }
  }

  announce(item) {
    const kind = item.level === 'error' ? 'error' : 'info';
    this.announcements[kind].push(item.message);
    if (this.announceFrame != null) return;
    // Hosts and empty live regions exist before content is inserted.
    this.announceFrame = this.win.requestAnimationFrame(() => {
      this.announceFrame = null;
      for (const name of ['info', 'error']) {
        const messages = this.announcements[name].splice(0);
        if (!messages.length) continue;
        this.regions[name].textContent = '';
        this.win.setTimeout(() => { this.regions[name].textContent = messages.join(' '); }, 25);
      }
    });
  }

  createCard(item) {
    const node = this.doc.createElement('div');
    node.className = 'fluxo-notification';
    node.dataset.level = item.level;
    node.dataset.notificationId = String(item.id);
    const label = this.doc.createElement('span');
    label.className = 'fluxo-notification__level';
    label.textContent = {success: 'Erfolg', info: 'Information', warning: 'Warnung', error: 'Fehler'}[item.level];
    const text = this.doc.createElement('p');
    text.className = 'fluxo-notification__message';
    text.textContent = item.message;
    const close = this.doc.createElement('button');
    close.type = 'button';
    close.className = 'fluxo-notification__close';
    close.setAttribute('aria-label', 'Meldung schließen');
    close.textContent = '×';
    const returnFocus = this.doc.activeElement;
    close.addEventListener('click', () => this.close(item.id));
    node.append(label, text, close);
    return {item, node, close, timer: null, returnFocus};
  }

  close(id) {
    const card = this.cards.get(id);
    const restore = card?.node.contains(this.doc.activeElement);
    const preferred = card?.returnFocus;
    this.state.remove(id);
    this.render();
    if (!restore) return;
    const candidates = [
      ...this.stack.querySelectorAll('button'),
      ...(this.more.hidden ? [] : [this.summary]),
      preferred !== this.doc.body && preferred !== this.doc.documentElement ? preferred : null,
      this.host.parentElement?.matches('dialog, .modal, [role="dialog"]') ? this.host.parentElement : null,
      this.doc.querySelector('main'), this.doc.body,
    ];
    for (const candidate of candidates) {
      if (!candidate?.isConnected || candidate.disabled || candidate.closest('[hidden], [inert]') || !candidate.getClientRects().length) continue;
      const temporary = !candidate.hasAttribute('tabindex') && !candidate.matches('a[href], button, input, select, textarea, summary');
      if (temporary) candidate.setAttribute('tabindex', '-1');
      candidate.focus({preventScroll: true});
      if (temporary) candidate.addEventListener('blur', () => candidate.removeAttribute('tabindex'), {once: true});
      if (this.doc.activeElement === candidate) break;
    }
    this.onFocus();
  }

  render() {
    this.moveToContext();
    const ids = new Set(this.state.items.map(item => item.id));
    for (const [id, card] of this.cards) {
      if (!ids.has(id)) { this.stopTimer(card); card.node.remove(); this.cards.delete(id); }
    }
    const visible = new Set(this.state.visible().map(item => item.id));
    for (const item of this.state.items) {
      let card = this.cards.get(item.id);
      if (!card) { card = this.createCard(item); this.cards.set(item.id, card); }
      const parent = visible.has(item.id) ? this.stack : this.archive;
      if (card.node.parentElement !== parent) {
        // Preserve keyboard reachability when a new error takes a visible place.
        const focused = card.node.contains(this.doc.activeElement) ? this.doc.activeElement : null;
        if (focused) this.more.open = true;
        parent.append(card.node);
        if (focused) focused.focus({preventScroll: true});
      }
    }
    const waiting = this.state.items.length - visible.size;
    this.more.hidden = waiting === 0;
    this.summary.textContent = `Weitere Meldungen (${waiting})`;
    if (!waiting && this.more.open) this.more.open = false;
    this.host.toggleAttribute('data-empty', this.state.items.length === 0);
    this.syncTimers();
  }

  notify(input) {
    const item = this.state.add(input);
    if (!item) return null;
    this.render();
    this.announce(item);
    return item.id;
  }

  scan(root = this.doc) {
    const nodes = [...root.querySelectorAll('[data-fluxo-notice]')];
    if (root.matches?.('[data-fluxo-notice]')) nodes.unshift(root);
    for (const node of nodes) {
      if (this.sources.has(node) || this.host.contains(node)) continue;
      this.sources.add(node);
      this.notify({message: node.textContent, level: node.dataset.level, eventId: node.dataset.eventId,
        persistent: node.dataset.persistent === 'true' || String(node.dataset.level).includes(':sticky')});
      node.remove();
    }
  }
}

export function initNotifications(options = {}) {
  if (typeof document === 'undefined') return null;
  if (!document.body) {
    document.addEventListener('DOMContentLoaded', () => initNotifications(options), {once: true});
    return null;
  }
  shared ||= new Notifications(document);
  shared.scan(options.root || document);
  return shared;
}

export function notify(options) {
  const instance = initNotifications();
  if (!instance) return null;
  return instance.notify(options);
}
