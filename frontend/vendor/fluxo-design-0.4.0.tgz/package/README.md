# Fluxo-Design

Gemeinsame Farben, lokale Schriften und Komponenten für fluxo.io-Anwendungen. Diese Quelle unter `CODEX/designs/fluxo` führt die bisherige Designbasis fort. Die Gestaltungsregeln stehen in [DESIGN.md](DESIGN.md), die markenübergreifende Übersicht unter [Farben](../FARBEN.md).

| Inhalt | Datei oder Ordner |
|---|---|
| Farben, Schriftketten, Radien, Schatten und Bewegung | [scss/_tokens.scss](scss/_tokens.scss) |
| Original-Logo | [assets/logo-fluxo_io.svg](assets/logo-fluxo_io.svg) |
| Open Sans und Anonymous Pro, jeweils Regular | [assets/fonts](assets/fonts/) |
| Gemeinsame Komponenten | [scss/components](scss/components/) |
| Tastaturfokus, Skip-Link, reduzierte Bewegung | [scss/_accessibility.scss](scss/_accessibility.scss) |
| Web- und Electron-Oberflächenhelfer | [scss/platforms](scss/platforms/) |
| Kompatible Website-Komponenten | [scss/website.css](scss/website.css) |
| Erzeugtes Website-CSS | [css](css/) |

Die Basis bleibt das private Paket `@fluxo/design@0.4.0`. [DON](../don/README.md), [WINHO](../winho/README.md) und [BNHO](../bnho/README.md) ergänzen Farben und Logos. Produktlayouts bleiben in den Anwendungen.

Technische Anleitungen: [Einbindung](../../skills/fluxo-node-webpack/references/design-integration.md), [Paketpflege](../../skills/fluxo-node-webpack/references/package-maintenance.md) und [optionaler Webpack-Preset](../../skills/fluxo-node-webpack/references/webpack.md).
