const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const tokens = JSON.parse(fs.readFileSync(path.join(root, 'tokens.json')));
function luminance(hex) {
  const c = [1,3,5].map(i => parseInt(hex.slice(i,i+2),16)/255).map(v=>v<=.04045?v/12.92:((v+.055)/1.055)**2.4);
  return c[0]*.2126+c[1]*.7152+c[2]*.0722;
}
for (const role of ['primary','primary-hover','success','warning','danger','info']) {
  const a=luminance(tokens[role]), b=luminance(tokens.surface);
  assert((Math.max(a,b)+.05)/(Math.min(a,b)+.05)>=4.5, `Insufficient contrast on ${role}`);
}
for (const [key,value] of Object.entries(tokens)) if (/^#[0-9a-f]{6}$/i.test(value)) {
  assert.equal(tokens[key+'-rgb'],[1,3,5].map(i=>parseInt(value.slice(i,i+2),16)).join(', '));
}
for (const relative of ['css/bootstrap.css','scss/adapters/bootstrap.scss','scss/adapters/_bootstrap-variables.scss','scss/platforms/bootstrap-web-shell.scss','assets/fonts/open-sans-v18-latin-regular.woff2','assets/fonts/anonymous-pro-v14-latin-regular.woff2']) {
  assert(fs.statSync(path.join(root, relative)).size>0, relative);
}
assert.equal(tokens['font-body-name'],'Open Sans');
assert.equal(tokens['font-heading-name'],'Anonymous Pro');
console.log('Design exports, derived RGB channels and six control text contrasts verified.');
