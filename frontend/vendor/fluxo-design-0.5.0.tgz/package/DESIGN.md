# fluxo.io – Design und Bedienung

Diese Datei führt die gemeinsamen Gestaltungs- und Bedienregeln. Maßgeblich für konkrete Werte sind [scss/_tokens.scss](scss/_tokens.scss), die Komponenten und die jeweiligen Kundenmanifeste. Die [Farbenübersicht](../FARBEN.md) macht die Farbrollen vergleichbar. Technische Zuständigkeiten stehen in den [Paketgrenzen](../../skills/fluxo-node-webpack/references/package-boundaries.md).

Gemeinsame Tokens und Komponenten werden als feste Paketversion in Anwendungen übernommen. Projekt-SCSS enthält eigene Layouts und fachliche Zustände; gemeinsame Designwerte werden dort nicht als unabhängige Kopie weitergepflegt. Aktuelle Produktentscheidungen und bestehende fremde Markenprofile bleiben maßgeblich. Kleine Änderungen begründen keine Neugestaltung des gesamten Produkts.

## Gestaltung und Texte

Helle Flächen, feine Linien, sparsame blaue Akzente und eine klare Hierarchie prägen das Fluxo-Profil. Arbeitsansichten sind kompakt und gut erfassbar; öffentliche Seiten dürfen großzügiger sein. Karten bündeln zusammengehörige Inhalte. Unnötige Karten in Karten vermeiden.

Suche, Daten und die nächste Handlung stehen im Mittelpunkt. Eine nachvollziehbare Navigation, ein eindeutiger Seitentitel und eine erkennbare primäre Aktion geben Orientierung. Aktive Bereiche auch semantisch kennzeichnen, beispielsweise mit `aria-current="page"`.

Oberflächentexte sind kurz und aus Nutzersicht formuliert: „Logbuch“, „Speichern“, „Keine Treffer“, „Filter zurücksetzen“. Entwicklungsanweisungen und technische Umsetzungsdetails gehören nicht in die Oberfläche. Hinweise nur ergänzen, wenn sie der Bedienung dienen. Leere Zustände nennen den Sachverhalt und gegebenenfalls eine passende Aktion. Echte produktbezogene Daten und vorhandene Assets bevorzugen.

Primärblau kennzeichnet Aktionen, Dunkelblau Überschriften. Weiß bleibt als Seitenhintergrund für Website und entsprechende Arbeitsflächen erhalten; `--fluxo-background` bietet eine zusätzliche dezente Fläche. Status und Bedeutung immer auch mit verständlichem Text vermitteln; fachliche Status- oder Diagrammfarben nicht durch reine Markenfarben ersetzen.

## Logo, Typografie und Icons

- Das originale [Fluxo-Logo](assets/logo-fluxo_io.svg) mit unveränderten Farben und Seitenverhältnis verwenden; Alternativtext `fluxo.io`. Vorhandene Logos nicht nachzeichnen oder durch erfundene Symbole ersetzen. Produktzusätze stehen separat.
- **Open Sans** für Fließtext, Navigation, Buttons, Breadcrumbs, Formulare, Tabellen und Hinweise. **Anonymous Pro** für Überschriften und gezielte technische Akzente wie große Kennzahlen oder die Leistungszeile. Vorhandene fremde Produktprofile behalten ihre Schriften.
- WOFF2-Dateien aus [assets/fonts](assets/fonts/) lokal mit `font-display: swap` laden. Die vorhandenen Dateien sind Regular-Schnitte; keine nicht vorhandenen Schnitte behaupten oder automatisch externe Fonts nachladen.
- Ein tatsächliches Fluxo-Produkt kann auf geschützten Einstiegsseiten `FLUXO.IO` → Produktname → `Geschützter Bereich` verwenden. Produktstatus gehört in den Kontext, nicht in die Wortmarke. Anbieterangaben und Datenflüsse bleiben projektbezogen; diese Basis enthält keine Rechtsvorlage.
- Icons verwenden, wenn sie Orientierung geben. Icons neben Text erhalten `aria-hidden="true"`; reine Icon-Buttons einen verständlichen zugänglichen Namen. Die [Iconbibliothek](../fontawesome/README.md) liefert Originalassets unabhängig von der gewählten Marke.

## Komponenten

Karten haben einen feinen Rand, den gemeinsamen Radius und einen ruhigen Schatten. Eine 4 px starke Oberkante in Primärfarbe (`card-accent` / `fluxo-card--accent`) kennzeichnet Hauptmodule wie Einstieg, zentrale Suche oder aktiven Prozess. Verlauf und Nebeninformationen bleiben ohne diesen Akzent. Kartenpolster von 1.25–1.5rem sind bewährte Startwerte, kein vorgeschriebenes Raster; Inhalt und vorhandenes Layout entscheiden.

Modul-Icons verwenden eine kleine Akzentfläche (`module-icon` / `fluxo-module-icon`). Buttons und Felder nutzen den Radius für Steuerelemente. Icon und Buttontext erhalten ihren Abstand über `gap`, nicht über zusätzliche Icon-Margins. Reine Icon-Buttons bleiben zentriert.

Die [SCSS-Komponenten](scss/components/) enthalten außerdem Markenblock, separaten Produktnamen, kleine Kontextzeile (`fluxo-eyebrow`) und Überschrift mit Kontext. Die [Plattformstile](scss/platforms/) ergänzen Webheader und -footer, eine zentrierte Anmeldeansicht mit Akzentkarte sowie Electron-Fensterbereiche und Safe-Area-Abstände.

Die folgenden Ausprägungen beschreiben den vorhandenen Komponentenstand. Pixelangaben entsprechen einer Basisschriftgröße von 16 px; die Quellwerte bleiben maßgeblich.

| Muster | Bestehende Ausprägung |
|---|---|
| Kartenradius | `0.75rem` / 12 px |
| Radius für Buttons, Felder und Modul-Icons | `0.5rem` / 8 px |
| Abstand zwischen Buttontext und Icon | `0.75rem` / 12 px |
| Modul-Icon | `2.75rem` × `2.75rem` / 44 × 44 px |
| SCSS-Button | mindestens `2.75rem` / 44 px hoch |
| Normales SCSS-Eingabefeld | mindestens `2.85rem` hoch |
| Floating Control | mindestens `3.4rem` hoch |
| Auth-Karte | Polster `1.5–2rem`, maximal `26rem` breit |
| Grundtypografie des SCSS-Core | `1rem`, Zeilenhöhe `1.6` |
| Seitentitel der SCSS-Komponente | `clamp(1.75rem, 3vw, 2.5rem)` |
| Kontextzeile | `0.75rem`, Gewicht `600`, Zeichenabstand `0.12em` |
| Kurze Übergänge | `140ms` |
| Kartenschatten | `0 0.25rem 1.25rem rgb(12 77 106 / 4.5%)` |
| Hover-Schatten | `0 0.5rem 1.625rem rgb(12 77 106 / 9%)` |
| Overlay-Schatten | `0 0.75rem 2.5rem rgb(12 77 106 / 18%)` |

Diese Maße erzwingen keine universelle Titelgröße, Sidebarbreite oder Seitenbreite. Neue Ansichten erhalten die zum Arbeitsablauf passende Navigation und Aufteilung.

## Formulare und Rückmeldungen

Echte, zugeordnete Labels verwenden; Placeholder ersetzen keine Beschriftung. Floating Labels sind optional und bleiben bei Fokus, Inhalt und Browser-Autofill lesbar. Fehler am betroffenen Feld oder Formular verständlich anzeigen und mit `aria-invalid` beziehungsweise `aria-describedby` zuordnen. Unkritische Eingaben nach Fehlern erhalten, Passwörter nicht wieder ausgeben. Anmeldefehler allgemein formulieren.

Interaktive Elemente zeigen Standard, Hover, Tastaturfokus, Aktiv und Deaktiviert. Asynchrone Aktionen ergänzen Laden, Erfolg und Fehler. Ladezustände erscheinen an der betroffenen Aktion oder Region, verhindern Doppelabsenden und behalten die Buttonbreite bei.

In Webapps nach `fluxo-webapp/1.0` verwenden allgemeine Aktionsmeldungen verbindlich den gemeinsamen [Meldungsadapter](../../skills/fluxo-product-design/references/notifications.md). Dort stehen Dauer, Pausen, Queue, Fokus, Live-Regionen und No-JS-Verhalten. Dauerhafte Zustände, Datenqualitätswarnungen und Feldfehler bleiben am Inhalt; dieselbe Meldung nicht zusätzlich sichtbar wiederholen. Andere Produktarten übernehmen Verhalten nur im beauftragten Umfang.

Die vorhandene Toast-Komponente ist ungefähr `25rem` breit und bleibt auf kleinen Ansichten innerhalb des Viewports. Toastdauer und Live-Regionen steuert das getrennte Paket `@fluxo/web-ui`; die Designstyles liefern kein Laufzeit-JavaScript. Das Verhindern doppelter Formularaktionen bleibt Aufgabe der Anwendung.

## Datenansichten

Suche und Filter stehen nachvollziehbar bei den Ergebnissen. Aktive Filter, Ergebnisanzahl und Paginierung verständlich halten. Exporte nur anbieten, wenn sie tatsächlich funktionieren und erlaubt sind.

Tabellen dürfen innerhalb ihres Containers horizontal scrollen; die ganze Seite läuft nicht über. Lange Inhalte sinnvoll kürzen oder umbrechen, wesentliche Informationen erreichbar halten. Tabellenüberschriften und Hover-Zeilen bleiben dezent. Diagramme erhalten eine lesbare Werteansicht oder Tabelle.

Datenaktualisierungen bewahren vorhandene Inhalte, Tastaturfokus, offene Details und möglichst die Scrollposition. Automatische Aktualisierung bleibt bedienbar und zeigt ihren Zustand verständlich. Aus einem bestehenden Produkt kein festes Aktualisierungsintervall für andere Anwendungen ableiten.

## Tastatur, Bewegung und kleine Ansichten

Der Tastaturfokus zeigt genau einen klaren 3-px-Ring mit zum Layout passendem Abstand von 3–4 px. Framework-Fokus und eigene Ringe nicht übereinanderstapeln. Hover ist weder die einzige Rückmeldung noch Voraussetzung für eine Handlung. Webapp-Shells erhalten einen Sprunglink und semantische Landmarken; Dialoge eine nachvollziehbare Fokusführung und Tastaturbedienung.

Touchziele möglichst 44 × 44 px groß gestalten; kompakte Desktop-Datenansichten dürfen enger sein. Mehrspaltige Inhalte flexibel umbauen und ihre sinnvolle Mindestbreite erhalten. Breakpoints richten sich nach dem jeweiligen Layout, nicht nach historischen Seitenbreiten anderer Projekte.

Kurze Übergänge betreffen Farbe, Rahmen, Schatten oder minimale Transformationen und verursachen keine Layoutsprünge. Die gemeinsame Basis bewegt Buttons beim Drücken um höchstens 1 px und interaktive Karten bei Hover um höchstens 2 px. Nicht notwendige Bewegung entfällt bei `prefers-reduced-motion`; Inhalte hängen nicht von Animationen ab. Karussells wechseln nicht automatisch.

## Produktprofile

Fluxo bleibt das Hauptdesign. [DON](../don/README.md), [WINHO](../winho/README.md) und [BNHO](../bnho/README.md) ergänzen ausschließlich Farben und unveränderte Original-Logos. Ohne Kundenauswahl gelten Fluxo-Farben und Fluxo-Logo. Gemeinsame Schriften, Komponenten und Bedienregeln sowie fachliche Statusfarben bleiben erhalten. Die Anwendung wählt das Kundenlogo separat.

Die öffentliche Fluxo-Website verwendet weiße großzügige Flächen, blaue Hervorhebungen, dunkle Abschnitte und Wellen. Navigation, Originalbilder, Produktscreenshots und Leistungszeile gehören zu ihrem Layout. Projektseiten bieten direkte Downloadlinks für verfügbare Plattformen; fehlende Dateien erhalten eine verständliche Fehlerseite. Website-Wellen, Marketingabschnitte und animierte Leistungszeilen sind keine Pflicht für Arbeitsoberflächen.

Webapps und Electron richten Produktnavigation, Tabellenlayout und Seitenbreiten nach ihrer Aufgabe aus. Bestehende fremde Markenprofile werden nicht automatisch durch Fluxo ersetzt. Historische Projektbeobachtungen bleiben im [datierten Quellenarchiv](../../archive/2026-10-13-before-reorganization/skills/skills/fluxo-product-design/references/design-system.md); sie begründen keine neuen Produktanforderungen oder fortlaufenden Umstellungsaufträge.

## Vorhandener Umsetzungsstand und Pflege

Die Gestaltungsregeln gelten unabhängig vom gewählten Einstieg. Das fertige Website-CSS gestaltet vorhandene Klassen wie `.card`, `.btn`, `.form-field` und `.module-icon`; die SCSS-Basis liefert `.fluxo-*`-Komponenten einschließlich Floating Labels und Toasts. Umfang und Einbindung beschreibt die [Designintegration](../../skills/fluxo-node-webpack/references/design-integration.md).

Das Website-CSS lässt den Seitenhintergrund offen; die SCSS-Basis setzt `--fluxo-background`. Eine weiße Website-Fläche wird im Website-Layout festgelegt. Der gemeinsame Fokusabstand beträgt 3 px (`--fluxo-focus-offset`). Die vorhandenen Überschriftenregeln adressieren `h1` bis `h4`.

Schatten, Formularränder, Trennlinien und Hover-Ränder leiten sich ab Version 0.5.0 ebenfalls aus den gemeinsamen Farbrollen ab. Kundenfarben einschließlich ihrer generierten RGB-Kanäle ersetzen die Markenrollen; fachliche Statusfarben bleiben eigenständig. Gedämpfte Texte und Statusfarben werden aus der Fluxo-Basis übernommen; `--fluxo-secondary` wird nur von den Kundenpaketen ergänzt.

Gemeinsame Gestaltungs- und Bedienregeln hier pflegen. Konkrete Werte in ihren Quelldateien ändern und die [Farbenübersicht](../FARBEN.md) abgleichen. [Paketpflege](../../skills/fluxo-node-webpack/references/package-maintenance.md) beschreibt Build, Versionierung und Übernahme. Betriebsanleitungen, Anbieterangaben, Datenschutztexte und Datenflüsse bleiben im jeweiligen Produkt- oder Infrastrukturkontext.


## Komponenten gemeinsam pflegen

Bootstrap-Webapps verwenden den zentralen Adapter aus `css/bootstrap.css` oder
`scss/adapters/bootstrap.scss`; die gemeinsame Verwaltungs-Shell ist opt-in unter
`scss/platforms/bootstrap-web-shell.scss` verfügbar. Allgemeine Button-, Feld-,
Tabellen-, Karten-, Fokus- und Statusregeln gehören ins Paket, nicht als Kopie in
jedes Projekt. Brandwahl umfasst auch RGB-Utilities wie `bg-primary`; eine bloße
Änderung von `--bs-primary` reicht nicht. Projektcode ergänzt Fachlayouts und
begründete Frameworkadapter, keine zweite Grundpalette.

Buttons, Navigation und Tabellen verwenden die Fließtextschrift; Überschriften
die Headingschrift. Charts übernehmen neutrale Schrift-/Text-/Rasterwerte aus
`tokens.json` als lokales Buildartefakt, während Kurvenfarben ihren fachlichen
Sinn behalten. Ein gesetztes npm-Paket allein belegt die Einhaltung nicht:
wirksame Farben und Schriften sowie die Zustände im Browser prüfen.

Favicon, Header-/Loginlogo, Apple-Touch-Icons und Webmanifest verwenden dieselbe
gewählte Marke. Bei Frameworks eigene Index-/Favicon-Defaults ausdrücklich
ersetzen und das tatsächlich ausgelieferte Symbol prüfen. Jede HTML-Shell erhält
einen funktionierenden Sprunglink, ein fokussierbares Hauptziel und semantische
Navigation; bei neuer Navigation aktive Bereiche markieren.
