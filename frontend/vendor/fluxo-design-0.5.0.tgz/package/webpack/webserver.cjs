const path = require("node:path");
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const { WebpackManifestPlugin } = require("webpack-manifest-plugin");

function resolveFrom(rootDir, value) {
  return path.isAbsolute(value) ? value : path.resolve(rootDir, value);
}

function resolveEntry(rootDir, entry) {
  if (typeof entry === "string") {
    return { main: resolveFrom(rootDir, entry) };
  }

  return Object.fromEntries(
    Object.entries(entry).map(([name, value]) => [name, resolveFrom(rootDir, value)]),
  );
}

function createWebserverConfig({
  rootDir = process.cwd(),
  entry,
  outputDir,
  publicPath = "",
  clean = true,
} = {}) {
  if (!entry) {
    throw new TypeError("createWebserverConfig requires an entry");
  }
  if (!outputDir) {
    throw new TypeError("createWebserverConfig requires an outputDir");
  }

  return (_env, argv = {}) => {
    const production = argv.mode === "production";

    return {
      context: rootDir,
      target: "web",
      entry: resolveEntry(rootDir, entry),
      output: {
        path: resolveFrom(rootDir, outputDir),
        filename: production ? "[name].[contenthash:8].js" : "[name].js",
        assetModuleFilename: production
          ? "assets/[name].[contenthash:8][ext]"
          : "assets/[name][ext]",
        clean,
        publicPath,
      },
      devtool: production ? false : "source-map",
      module: {
        rules: [
          {
            test: /\.s?css$/i,
            use: [
              MiniCssExtractPlugin.loader,
              { loader: "css-loader", options: { sourceMap: !production, url: true } },
              {
                loader: "sass-loader",
                options: {
                  sourceMap: !production,
                  sassOptions: { quietDeps: true },
                },
              },
            ],
          },
          {
            test: /\.(woff2?|ttf|eot|svg)$/i,
            type: "asset/resource",
          },
        ],
      },
      plugins: [
        new MiniCssExtractPlugin({
          filename: production ? "[name].[contenthash:8].css" : "[name].css",
        }),
        new WebpackManifestPlugin({ publicPath }),
      ],
      performance: { hints: false },
    };
  };
}

module.exports = { createWebserverConfig };
