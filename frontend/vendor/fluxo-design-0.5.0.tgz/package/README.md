# Fluxo-Design

Gemeinsame Farben, lokale Schriften und Komponenten für fluxo.io-Anwendungen. Diese Quelle unter `CODEX/designs/fluxo` führt die bisherige Designbasis fort. Die Gestaltungsregeln stehen in [DESIGN.md](DESIGN.md), die markenübergreifende Übersicht unter [Farben](../FARBEN.md).

| Inhalt | Datei oder Ordner |
|---|---|
| Farben, Schriftketten, Radien, Schatten und Bewegung | [scss/_tokens.scss](scss/_tokens.scss) |
| Original-Logo | [assets/logo-fluxo_io.svg](assets/logo-fluxo_io.svg) |
| Open Sans und Anonymous Pro, jeweils Regular | [assets/fonts](assets/fonts/) |
| Gemeinsame Komponenten | [scss/components](scss/components/) |
| Tastaturfokus, Skip-Link, reduzierte Bewegung | [scss/_accessibility.scss](scss/_accessibility.scss) |
| Web- und Electron-Oberflächenhelfer | [scss/platforms](scss/platforms/) |
| Kompatible Website-Komponenten | [scss/website.css](scss/website.css) |
| Erzeugtes Website-CSS | [css](css/) |

Die Basis bleibt das private Paket `@fluxo/design@0.5.0`. [DON](../don/README.md), [WINHO](../winho/README.md) und [BNHO](../bnho/README.md) ergänzen Farben und Logos. Produktlayouts bleiben in den Anwendungen.

Technische Anleitungen: [Einbindung](../../skills/fluxo-node-webpack/references/design-integration.md), [Paketpflege](../../skills/fluxo-node-webpack/references/package-maintenance.md) und [optionaler Webpack-Preset](../../skills/fluxo-node-webpack/references/webpack.md).


Version 0.5.0 ergänzt einen gemeinsamen Bootstrap-Adapter (`css/bootstrap.css`
beziehungsweise `scss/adapters/bootstrap.scss`) und die opt-in Web-Shell
`scss/platforms/bootstrap-web-shell.scss`. Der Adapter folgt auf Bootstrap und
Basis/Kundenfarben; er importiert Bootstrap nicht. Die Web-Shell lädt den Core
selbst und vereinheitlicht Header, Navigation, Anmeldekarten, Module und Footer.
Produktlayouts und Fachfarben bleiben im Produkt. Die Logobreiten lassen sich
über `--fluxo-shell-logo-width`/`--fluxo-shell-logo-width-mobile`, die Inhaltsbreite
über `--fluxo-shell-max-width` anpassen.

`tokens.json`, `scss/_color-channels.scss` und
`scss/adapters/_bootstrap-variables.scss` werden aus der einzigen Tokenquelle
`scss/_tokens.scss` erzeugt. JSON verwendet die CSS-Rollennamen ohne Präfix und
zusätzlich `font-body-name`/`font-heading-name`. Ein Canvas-/Plotly-Renderer
übernimmt die benötigten Werte in seinen lokalen Build; er liest nicht die
zentrale Bibliothek zur Laufzeit. Kundenfarben benötigen auch die passenden
`*-rgb`-Rollen, für BNHO liefert sie Version 0.1.3. Das JSON beschreibt die
Fluxo-Basis; Kundenoverrides werden bei entsprechendem Bedarf im Produktbuild
angewendet. Ausdruckswerte wie `color-mix(...)` sind keine fertigen Canvasfarben.

`npm run build:css && npm run check` prüft Exporte, abgeleitete RGB-Werte und
Textkontraste. `npm pack` erzeugt das feste lokale Paketarchiv. Die erzeugten
Dateien werden nicht von Hand bearbeitet.
