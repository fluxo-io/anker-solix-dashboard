"""Shared SQLite identity, login and session contract for Fluxo webapps.

The caller owns the DBAPI connection and transaction. This module never commits,
rolls back or closes that connection, and never opens a second database.
"""
from .core import (
    VERSION, DEFAULT_SESSION_SECONDS, User, UserStore, AuthService, LoginResult,
    normalize_username, hash_password, verify_password, session_seconds,
    configure_flask_session,
)

__all__ = [
    "VERSION", "DEFAULT_SESSION_SECONDS", "User", "UserStore", "AuthService",
    "LoginResult", "normalize_username", "hash_password", "verify_password",
    "session_seconds", "configure_flask_session",
]
