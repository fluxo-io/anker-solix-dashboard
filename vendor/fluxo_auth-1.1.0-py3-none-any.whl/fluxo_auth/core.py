from __future__ import annotations

from dataclasses import dataclass, field, replace
from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from functools import lru_cache
import hashlib
import hmac
import json
import math
import re
import secrets
import sqlite3
import time
import unicodedata
from typing import Any, Mapping

from werkzeug.security import check_password_hash, generate_password_hash

VERSION = "1.1.0"
DEFAULT_SESSION_SECONDS = 8 * 60 * 60
MAX_SESSION_SECONDS = 31 * 24 * 60 * 60
_TOKEN = re.compile(r"fa1_[A-Za-z0-9_-]{43}\Z")
_UNSET = object()

_DDL = (
    """CREATE TABLE IF NOT EXISTS auth_meta (
        key TEXT PRIMARY KEY, value TEXT NOT NULL)""",
    """CREATE TABLE IF NOT EXISTS auth_users (
        id TEXT PRIMARY KEY, username TEXT NOT NULL, login_key TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL, active INTEGER NOT NULL CHECK(active IN (0,1)),
        revision TEXT NOT NULL,
        must_change_password INTEGER NOT NULL CHECK(must_change_password IN (0,1)),
        authorization_json TEXT NOT NULL, metadata_json TEXT NOT NULL,
        created_at TEXT NOT NULL, updated_at TEXT NOT NULL, last_login_at TEXT)""",
    """CREATE TABLE IF NOT EXISTS auth_sessions (
        token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL, revision TEXT NOT NULL,
        issued_at REAL NOT NULL, expires_at REAL NOT NULL,
        FOREIGN KEY(user_id) REFERENCES auth_users(id) ON DELETE CASCADE)""",
    "CREATE INDEX IF NOT EXISTS auth_sessions_user ON auth_sessions(user_id)",
    "CREATE INDEX IF NOT EXISTS auth_sessions_expiry ON auth_sessions(expires_at)",
    """CREATE TABLE IF NOT EXISTS auth_login_attempts (
        id TEXT PRIMARY KEY, client_key TEXT NOT NULL, attempted_at REAL NOT NULL,
        pending INTEGER NOT NULL CHECK(pending IN (0,1)))""",
    "CREATE INDEX IF NOT EXISTS auth_attempts_key_time ON auth_login_attempts(client_key,attempted_at)",
    """CREATE TABLE IF NOT EXISTS auth_legacy_limits (
        source TEXT NOT NULL, key TEXT NOT NULL, count INTEGER NOT NULL,
        maximum INTEGER NOT NULL, expires_at REAL NOT NULL, blocked_until REAL NOT NULL,
        PRIMARY KEY(source,key))""",
)
_COLUMNS = {
    "auth_meta": ("key", "value"),
    "auth_users": ("id", "username", "login_key", "password_hash", "active",
                   "revision", "must_change_password", "authorization_json",
                   "metadata_json", "created_at", "updated_at", "last_login_at"),
    "auth_sessions": ("token_hash", "user_id", "revision", "issued_at", "expires_at"),
    "auth_login_attempts": ("id", "client_key", "attempted_at", "pending"),
    "auth_legacy_limits": ("source", "key", "count", "maximum", "expires_at", "blocked_until"),
}


def _now(value=None) -> float:
    result = time.time() if value is None else float(value)
    if not math.isfinite(result):
        raise ValueError("Ungültiger Zeitpunkt.")
    return result


def _stamp() -> str:
    return datetime.now(timezone.utc).isoformat()


def _login_stamp(value) -> str | None:
    """Import only an unambiguous historical instant; never guess its zone."""
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError("Ungültiger Anmeldezeitpunkt.")
    try:
        parsed = datetime.fromisoformat(value)
        if parsed.tzinfo is None or parsed.utcoffset() is None:
            raise ValueError
        return parsed.astimezone(timezone.utc).isoformat()
    except (ValueError, OverflowError):
        raise ValueError("Ungültiger Anmeldezeitpunkt.") from None


def _legacy_login_stamp(metadata) -> str | None:
    try:
        return _login_stamp(metadata.get("last_login"))
    except (AttributeError, ValueError):
        return None


def _json(value: Mapping | None) -> str:
    if value is None:
        value = {}
    if not isinstance(value, Mapping):
        raise ValueError("Benutzermetadaten müssen ein Objekt sein.")
    return json.dumps(dict(value), ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False)


def _secret(value: str | bytes) -> bytes:
    raw = value.encode("utf-8") if isinstance(value, str) else value
    if not isinstance(raw, bytes) or len(raw) < 32:
        raise ValueError("SECRET_KEY benötigt mindestens 32 Bytes.")
    return raw


def normalize_username(value: str) -> str:
    if not isinstance(value, str):
        raise ValueError("Benutzername ist ungültig.")
    result = unicodedata.normalize("NFC", value.strip())
    if not 1 <= len(result) <= 254 or any(unicodedata.category(c).startswith("C") for c in result):
        raise ValueError("Benutzername ist ungültig.")
    return result.casefold()


def hash_password(password: str) -> str:
    if not isinstance(password, str) or not 12 <= len(password) <= 1024:
        raise ValueError("Das Passwort muss 12 bis 1024 Zeichen lang sein.")
    return generate_password_hash(password, method="scrypt:32768:8:1")


def verify_password(password_hash: str, password: str) -> bool:
    # New passwords are bounded by hash_password. Existing hashes may predate
    # that policy; request-size limits belong to the HTTP boundary.
    if not isinstance(password, str) or not password:
        return False
    if not isinstance(password_hash, str) or not password_hash:
        return False
    try:
        if password_hash.startswith(("$2a$", "$2b$", "$2y$")):
            # Only historical BNHO data needs bcrypt. New passwords use scrypt.
            # bcrypt historically truncated after72bytes; preserve that verification.
            import bcrypt
            encoded = password_hash.replace("$2y$", "$2b$", 1).encode("ascii")
            return bcrypt.checkpw(password.encode("utf-8")[:72], encoded)
        return bool(check_password_hash(password_hash, password))
    except (ValueError, TypeError, UnicodeError, OverflowError):
        return False


@lru_cache(maxsize=1)
def _dummy_password() -> str:
    return hash_password(secrets.token_urlsafe(32))


def session_seconds(environment: Mapping[str, Any], default=DEFAULT_SESSION_SECONDS) -> int:
    values = []
    for key, multiplier in (("SESSION_HOURS", 3600), ("SESSION_LIFETIME_MINUTES", 60)):
        raw = environment.get(key)
        if raw is not None and str(raw).strip():
            try:
                seconds = Decimal(str(raw).strip()) * multiplier
            except (InvalidOperation, ValueError):
                raise ValueError("Sitzungsdauer ist ungültig.") from None
            if not seconds.is_finite() or seconds != seconds.to_integral_value():
                raise ValueError("Sitzungsdauer muss ganze Sekunden ergeben.")
            values.append(int(seconds))
    if len(set(values)) > 1:
        raise ValueError("SESSION_HOURS und SESSION_LIFETIME_MINUTES widersprechen sich.")
    if not values:
        try:
            fallback = Decimal(str(default))
        except InvalidOperation:
            raise ValueError("Sitzungsdauer ist ungültig.") from None
        if not fallback.is_finite() or fallback != fallback.to_integral_value():
            raise ValueError("Sitzungsdauer muss ganze Sekunden ergeben.")
        values.append(int(fallback))
    result = values[0]
    if not 1 <= result <= MAX_SESSION_SECONDS:
        raise ValueError("Sitzungsdauer muss zwischen einer Sekunde und 31 Tagen liegen.")
    return result


def configure_flask_session(app, cookie_name: str, secure: bool, lifetime_seconds: int) -> None:
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,80}", cookie_name):
        raise ValueError("SESSION_COOKIE_NAME ist ungültig.")
    if cookie_name.startswith(("__Host-", "__Secure-")) and not secure:
        raise ValueError("Der Cookie-Präfix benötigt HTTPS.")
    duration = session_seconds({}, default=lifetime_seconds)
    app.config.update(
        SESSION_COOKIE_NAME=cookie_name, SESSION_COOKIE_SECURE=bool(secure),
        SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_PATH="/", SESSION_COOKIE_DOMAIN=None,
        PERMANENT_SESSION_LIFETIME=timedelta(seconds=duration),
        SESSION_REFRESH_EACH_REQUEST=False, WTF_CSRF_TIME_LIMIT=duration,
        SESSION_PROTECTION="basic",
    )


@dataclass(frozen=True)
class User:
    id: str
    username: str
    password_hash: str = field(repr=False)
    active: bool
    revision: str = field(repr=False)
    must_change_password: bool
    authorization: dict
    metadata: dict
    created_at: str
    updated_at: str
    last_login_at: str | None = None


@dataclass(frozen=True)
class LoginResult:
    user: User | None = None
    token: str | None = field(default=None, repr=False)
    retry_after: int | None = None
    error: str | None = None


class UserStore:
    def __init__(self, connection):
        self.connection = connection

    def _write(self):
        if getattr(self.connection, "in_transaction", True) is False:
            raise RuntimeError("Auth-Schreibzugriff benötigt eine aktive Transaktion.")

    def ensure_schema(self):
        self._write()
        present = {row[0] for row in self.connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name IN (?,?,?,?,?)",
            tuple(_COLUMNS))}
        if present:
            if present != set(_COLUMNS):
                raise RuntimeError("Unvollständiges oder unbekanntes Authschema; Bestand unverändert lassen.")
            if self._schema_ready("1"):
                self.connection.execute("ALTER TABLE auth_users ADD COLUMN last_login_at TEXT")
                for identity, raw in self.connection.execute("SELECT id,metadata_json FROM auth_users").fetchall():
                    stamp = _legacy_login_stamp(json.loads(raw))
                    if stamp is not None:
                        self.connection.execute("UPDATE auth_users SET last_login_at=? WHERE id=?", (stamp, identity))
                self.connection.execute("UPDATE auth_meta SET value='2' WHERE key='schema_version'")
            if not self.schema_ready():
                raise RuntimeError("Unvollständiges oder unbekanntes Authschema; Bestand unverändert lassen.")
            return
        for sql in _DDL:
            self.connection.execute(sql)
        found = self.connection.execute("SELECT value FROM auth_meta WHERE key='schema_version'").fetchone()
        if found and str(found[0]) != "2":
            raise RuntimeError("Unbekanntes Authschema; Bestand unverändert lassen.")
        self.connection.execute("INSERT OR IGNORE INTO auth_meta(key,value) VALUES('schema_version','2')")
        if not self.schema_ready():
            raise RuntimeError("Unvollständiges Authschema; Bestand unverändert lassen.")

    def schema_ready(self) -> bool:
        return self._schema_ready("2")

    def _schema_ready(self, version) -> bool:
        try:
            row = self.connection.execute("SELECT value FROM auth_meta WHERE key='schema_version'").fetchone()
            if not row or row[0] != version:
                return False
            for table, expected in _COLUMNS.items():
                if version == "1" and table == "auth_users":
                    expected = expected[:-1]
                columns = tuple(row[1] for row in self.connection.execute(f"PRAGMA table_info({table})"))
                if columns != expected:
                    return False
                definition = self.connection.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone()
                if definition is None or not isinstance(definition[0], str):
                    return False
                actual = definition[0]
                canonical = next(sql for sql in _DDL if sql.startswith("CREATE TABLE IF NOT EXISTS " + table + " ("))
                if version == "1" and table == "auth_users":
                    canonical = canonical.replace(", last_login_at TEXT", "")
                normalize = lambda sql: re.sub(r"\s+", "", sql.replace("IF NOT EXISTS ", "")).lower()
                if normalize(actual) != normalize(canonical):
                    return False
            return True
        except sqlite3.DatabaseError:
            return False

    @staticmethod
    def _user(row) -> User | None:
        if row is None:
            return None
        data = dict(zip(_COLUMNS["auth_users"], tuple(row)))
        return User(
            id=data["id"], username=data["username"], password_hash=data["password_hash"],
            active=bool(data["active"]), revision=data["revision"],
            must_change_password=bool(data["must_change_password"]),
            authorization=json.loads(data["authorization_json"]),
            metadata=json.loads(data["metadata_json"]), created_at=data["created_at"],
            updated_at=data["updated_at"],
            last_login_at=data["last_login_at"],
        )

    def get(self, user_id) -> User | None:
        return self._user(self.connection.execute("SELECT * FROM auth_users WHERE id=?", (str(user_id),)).fetchone())

    def find(self, username) -> User | None:
        try:
            key = normalize_username(username)
        except ValueError:
            return None
        return self._user(self.connection.execute("SELECT * FROM auth_users WHERE login_key=?", (key,)).fetchone())

    def all(self) -> list[User]:
        return [self._user(row) for row in self.connection.execute("SELECT * FROM auth_users ORDER BY login_key,id")]

    def count(self) -> int:
        return int(self.connection.execute("SELECT COUNT(*) FROM auth_users").fetchone()[0])

    def create(self, *, id, username, password_hash, active=True,
               authorization=None, metadata=None, must_change_password=False,
               revision=None, created_at=None, updated_at=None, last_login_at=_UNSET) -> User:
        self._write()
        key = normalize_username(username)
        identity = str(id)
        if not identity or len(identity) > 512 or not isinstance(password_hash, str):
            raise ValueError("Ungültiger Benutzerbestand.")
        if not isinstance(active, bool) or not isinstance(must_change_password, bool):
            raise ValueError("Ungültiger Benutzerstatus.")
        created = str(created_at) if created_at is not None else _stamp()
        updated = str(updated_at) if updated_at is not None else created
        last_login = (_legacy_login_stamp(metadata) if last_login_at is _UNSET
                      else _login_stamp(last_login_at))
        self.connection.execute(
            "INSERT INTO auth_users VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
            (identity, unicodedata.normalize("NFC", username.strip()), key, password_hash,
             int(active), str(revision) if revision is not None else secrets.token_hex(32),
             int(must_change_password), _json(authorization), _json(metadata), created, updated, last_login),
        )
        return self.get(identity)

    def update(self, user_id, *, username=_UNSET, password_hash=_UNSET,
               active=_UNSET, authorization=_UNSET, metadata=_UNSET,
               must_change_password=_UNSET) -> User:
        self._write()
        old = self.get(user_id)
        if old is None:
            raise KeyError(str(user_id))
        data = {"username": username, "password_hash": password_hash, "active": active,
                "authorization": authorization, "metadata": metadata,
                "must_change_password": must_change_password}
        changes = {key: value for key, value in data.items() if value is not _UNSET}
        new = replace(old, **changes)
        key = normalize_username(new.username)
        if not isinstance(new.active, bool) or not isinstance(new.must_change_password, bool):
            raise ValueError("Ungültiger Benutzerstatus.")
        if not isinstance(new.password_hash, str):
            raise ValueError("Ungültiger Passwort-Hash.")
        auth_json, meta_json = _json(new.authorization), _json(new.metadata)
        security_changed = (
            new.username != old.username or new.password_hash != old.password_hash
            or new.active != old.active or new.must_change_password != old.must_change_password
            or auth_json != _json(old.authorization)
        )
        revision = secrets.token_hex(32) if security_changed else old.revision
        self.connection.execute(
            """UPDATE auth_users SET username=?,login_key=?,password_hash=?,active=?,
                revision=?,must_change_password=?,authorization_json=?,metadata_json=?,
                updated_at=? WHERE id=?""",
            (unicodedata.normalize("NFC", new.username.strip()), key, new.password_hash,
             int(new.active), revision, int(new.must_change_password), auth_json, meta_json,
             _stamp(), old.id),
        )
        if security_changed:
            self.connection.execute("DELETE FROM auth_sessions WHERE user_id=?", (old.id,))
        return self.get(old.id)

    def delete(self, user_id) -> bool:
        self._write()
        self.connection.execute("DELETE FROM auth_sessions WHERE user_id=?", (str(user_id),))
        return bool(self.connection.execute("DELETE FROM auth_users WHERE id=?", (str(user_id),)).rowcount)

    def migration_applied(self, source: str) -> bool:
        return self.connection.execute("SELECT 1 FROM auth_meta WHERE key=?", ("migration:" + source,)).fetchone() is not None

    def import_legacy(self, source: str, records) -> int:
        self._write()
        if self.migration_applied(source):
            return 0
        records = list(records)
        identities, logins = set(), set()
        for item in records:
            identity, key = str(item["id"]), normalize_username(item["username"])
            if identity in identities or key in logins or self.get(identity) or self.find(item["username"]):
                raise ValueError("Kollidierende Benutzer im Altbestand; Migration abgebrochen.")
            identities.add(identity)
            logins.add(key)
            _json(item.get("authorization"))
            _json(item.get("metadata"))
        self.connection.execute("SAVEPOINT fluxo_auth_import")
        try:
            for item in records:
                self.create(**item)
            self.connection.execute("INSERT INTO auth_meta(key,value) VALUES(?,?)",
                                    ("migration:" + source, json.dumps({"count": len(records), "at": _stamp()})))
        except BaseException:
            self.connection.execute("ROLLBACK TO fluxo_auth_import")
            self.connection.execute("RELEASE fluxo_auth_import")
            raise
        self.connection.execute("RELEASE fluxo_auth_import")
        return len(records)

    def reserve_numeric_ids(self, namespace: str, floor: int) -> None:
        self._write()
        if int(floor) < 0:
            raise ValueError("Ungültiger ID-Höchststand.")
        key = "sequence:" + namespace
        old = self.connection.execute("SELECT value FROM auth_meta WHERE key=?", (key,)).fetchone()
        value = max(int(floor), int(old[0]) if old else 0)
        self.connection.execute("INSERT INTO auth_meta VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))

    def next_numeric_id(self, namespace: str) -> str:
        self._write()
        key = "sequence:" + namespace
        row = self.connection.execute("SELECT value FROM auth_meta WHERE key=?", (key,)).fetchone()
        highest = max((int(user.id) for user in self.all() if user.id.isdecimal()), default=0)
        value = max(highest, int(row[0]) if row else 0) + 1
        self.reserve_numeric_ids(namespace, value)
        return str(value)

    def import_limits(self, source: str, records) -> int:
        self._write()
        marker = "limits:" + source
        if self.migration_applied(marker):
            return 0
        records = list(records)
        self.connection.execute("SAVEPOINT fluxo_auth_limits")
        try:
            for row in records:
                count, maximum = int(row["count"]), int(row["limit"])
                if count < 0 or maximum < 1:
                    raise ValueError("Ungültige Anmeldesperre.")
                self.connection.execute("INSERT INTO auth_legacy_limits VALUES(?,?,?,?,?,?)",
                                        (source, str(row["key"]), count, maximum,
                                         _now(row["expires_at"]), _now(row.get("blocked_until", 0))))
            self.connection.execute("INSERT INTO auth_meta VALUES(?,?)", ("migration:" + marker, _stamp()))
        except BaseException:
            self.connection.execute("ROLLBACK TO fluxo_auth_limits")
            self.connection.execute("RELEASE fluxo_auth_limits")
            raise
        self.connection.execute("RELEASE fluxo_auth_limits")
        return len(records)

    def import_attempts(self, source: str, records) -> int:
        self._write()
        marker = "attempts:" + source
        if self.migration_applied(marker):
            return 0
        records = list(records)
        self.connection.execute("SAVEPOINT fluxo_auth_attempts")
        try:
            for row in records:
                pending = int(row.get("pending", 0))
                if pending not in (0, 1):
                    raise ValueError("Ungültiger Anmeldeversuch.")
                self.connection.execute("INSERT INTO auth_login_attempts VALUES(?,?,?,?)",
                    ("legacy:" + json.dumps([source, str(row["id"])]),
                     self._legacy_attempt_key(source, row["client_key"]),
                     _now(row["attempted_at"]), pending))
            self.connection.execute("INSERT INTO auth_meta VALUES(?,?)", ("migration:" + marker, _stamp()))
        except BaseException:
            self.connection.execute("ROLLBACK TO fluxo_auth_attempts")
            self.connection.execute("RELEASE fluxo_auth_attempts")
            raise
        self.connection.execute("RELEASE fluxo_auth_attempts")
        return len(records)

    @staticmethod
    def _legacy_attempt_key(source, key):
        return "legacy:" + json.dumps([str(source), str(key)])

    def prune_auth(self, now=None):
        self._write()
        stamp = _now(now)
        self.connection.execute("DELETE FROM auth_sessions WHERE expires_at<=?", (stamp,))
        self.connection.execute("DELETE FROM auth_login_attempts WHERE attempted_at<=?", (stamp - 3600,))
        self.connection.execute("DELETE FROM auth_legacy_limits WHERE expires_at<=?", (stamp,))


class AuthService:
    def __init__(self, store: UserStore, secret: str | bytes,
                 lifetime_seconds=DEFAULT_SESSION_SECONDS):
        self.store = store
        self.db = store.connection
        self.secret = _secret(secret)
        self.lifetime_seconds = session_seconds({}, default=lifetime_seconds)

    def _digest(self, value: str) -> str:
        return hmac.new(self.secret, value.encode("utf-8"), hashlib.sha256).hexdigest()

    def issue(self, user_id, now=None) -> str:
        self.store._write()
        user = self.store.get(user_id)
        if user is None or not user.active:
            raise ValueError("Benutzer ist nicht aktiv.")
        stamp = _now(now)
        token = "fa1_" + secrets.token_urlsafe(32)
        self.db.execute("DELETE FROM auth_sessions WHERE expires_at<=?", (stamp,))
        self.db.execute("INSERT INTO auth_sessions VALUES(?,?,?,?,?)",
                        (self._digest("session:" + token), user.id, user.revision,
                         stamp, stamp + self.lifetime_seconds))
        return token

    def constrain_lifetime(self) -> None:
        """Apply a configuration change at startup without later reviving tokens.

        Call inside the API's startup transaction after schema migration. Reads
        remain immutable; each persisted expiry can only become earlier.
        """
        self.store._write()
        self.db.execute(
            "UPDATE auth_sessions SET expires_at=issued_at+? WHERE expires_at>issued_at+?",
            (self.lifetime_seconds, self.lifetime_seconds))

    def session_info(self, token: str, now=None) -> dict | None:
        if not isinstance(token, str) or not _TOKEN.fullmatch(token):
            return None
        row = self.db.execute("SELECT user_id,revision,issued_at,expires_at FROM auth_sessions WHERE token_hash=?",
                              (self._digest("session:" + token),)).fetchone()
        if row is None:
            return None
        stamp = _now(now)
        identity, revision, issued, expires = row
        if not all(math.isfinite(float(x)) for x in (issued, expires)):
            return None
        if not issued <= stamp < min(expires, issued + self.lifetime_seconds):
            return None
        user = self.store.get(identity)
        if user is None or not user.active or not hmac.compare_digest(user.revision.encode(), revision.encode()):
            return None
        return {"user": user, "issued_at": float(issued), "expires_at": min(float(expires), issued + self.lifetime_seconds)}

    def validate(self, token: str, now=None) -> User | None:
        info = self.session_info(token, now=now)
        return info["user"] if info else None

    def logout(self, token: str) -> bool:
        self.store._write()
        if not isinstance(token, str) or not _TOKEN.fullmatch(token):
            return False
        return bool(self.db.execute("DELETE FROM auth_sessions WHERE token_hash=?", (self._digest("session:" + token),)).rowcount)

    def revoke_user(self, user_id) -> User:
        self.store._write()
        user = self.store.get(user_id)
        if user is None:
            raise KeyError(str(user_id))
        self.db.execute("UPDATE auth_users SET revision=?,updated_at=? WHERE id=?", (secrets.token_hex(32), _stamp(), user.id))
        self.db.execute("DELETE FROM auth_sessions WHERE user_id=?", (user.id,))
        return self.store.get(user.id)

    def _reserve(self, keys, stamp, legacy_keys, legacy_attempt_keys):
        self.store._write()
        self.db.execute("DELETE FROM auth_login_attempts WHERE attempted_at<=?", (stamp - 3600,))
        self.db.execute("DELETE FROM auth_legacy_limits WHERE expires_at<=?", (stamp,))
        waits = []
        for source, key in legacy_keys:
            row = self.db.execute("SELECT count,maximum,expires_at,blocked_until FROM auth_legacy_limits WHERE source=? AND key=?", (source, key)).fetchone()
            if row and (row[0] >= row[1] or row[3] > stamp):
                waits.append(max(row[3], row[2]) - stamp)
        for position, key in enumerate(keys):
            stamps = [row[0] for row in self.db.execute("SELECT attempted_at FROM auth_login_attempts WHERE client_key=? ORDER BY attempted_at", (key,))]
            if position == 1:
                for source, old_key in legacy_attempt_keys:
                    stamps.extend(row[0] for row in self.db.execute(
                        "SELECT attempted_at FROM auth_login_attempts WHERE client_key=?",
                        (self.store._legacy_attempt_key(source, old_key),)))
                stamps.sort()
            recent = [value for value in stamps if value > stamp - 300]
            if len(recent) >= 5:
                waits.append(recent[-5] + 300 - stamp)
            if len(stamps) >= 20:
                waits.append(stamps[-20] + 3600 - stamp)
        if waits:
            return [], max(1, math.ceil(max(waits)))
        reservations = []
        for key in keys:
            identity = secrets.token_hex(16)
            self.db.execute("INSERT INTO auth_login_attempts VALUES(?,?,?,1)", (identity, key, stamp))
            reservations.append(identity)
        return reservations, None

    def login(self, username, password, client_key, now=None, legacy_keys=(),
              legacy_client_keys=(), legacy_attempt_keys=()) -> LoginResult:
        self.store._write()
        stamp = _now(now)
        if not isinstance(client_key, str) or not client_key or len(client_key) > 1024:
            raise ValueError("Ungültiger Login-Clientkontext.")
        try:
            name = normalize_username(username)
        except ValueError:
            name = "invalid"
        keys = (self._digest("account:" + name), self._digest("client:" + client_key))
        legacy_client_keys = set(tuple(pair) for pair in legacy_client_keys)
        legacy_keys = tuple(dict.fromkeys([*(tuple(pair) for pair in legacy_keys), *legacy_client_keys]))
        legacy_attempt_keys = tuple(dict.fromkeys(tuple(pair) for pair in legacy_attempt_keys))
        reservations, retry = self._reserve(keys, stamp, legacy_keys, legacy_attempt_keys)
        if retry is not None:
            return LoginResult(retry_after=retry, error="rate_limited")
        user = self.store.find(username)
        valid = verify_password(user.password_hash if user else _dummy_password(), password)
        if user is not None and user.active and valid:
            token = self.issue(user.id, now=stamp)
            self.db.execute("UPDATE auth_users SET last_login_at=? WHERE id=?",
                            (datetime.fromtimestamp(stamp, timezone.utc).isoformat(), user.id))
            self.db.execute("DELETE FROM auth_login_attempts WHERE client_key=? AND (pending=0 OR id=?)", (keys[0], reservations[0]))
            self.db.execute("DELETE FROM auth_login_attempts WHERE id=?", (reservations[1],))
            for source, key in legacy_keys:
                if (source, key) not in legacy_client_keys:
                    self.db.execute("DELETE FROM auth_legacy_limits WHERE source=? AND key=?", (source, key))
            return LoginResult(user=self.store.get(user.id), token=token)
        for reservation in reservations:
            self.db.execute("UPDATE auth_login_attempts SET pending=0 WHERE id=?", (reservation,))
        for source, key in legacy_keys:
            self.db.execute("UPDATE auth_legacy_limits SET count=count+1 WHERE source=? AND key=?", (source, key))
        return LoginResult(error="invalid_credentials")
